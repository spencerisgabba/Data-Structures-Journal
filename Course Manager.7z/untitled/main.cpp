#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <set>
#include <utility>
#include <chrono>


//Spencer Schmidt

using namespace std;
using namespace chrono;

class Course {
public:
    string name;
    string id;
    set<string> prerequisites;

    Course() = default;
    Course(const string& name, const string& id) : name(name), id(id) {}

    void addPrerequisite(const string& prereq) {
        prerequisites.insert(prereq);
    }
};
// Loads course data from a file into an unordered_map.
// Input: fileName - The absolute path to the file containing course data.
// Output: courses - The unordered_map to store course information.
void loadDataStructure(const string& fileName, unordered_map<string, Course>& courses) {
    auto start = high_resolution_clock::now(); // Start timing

    ifstream file(fileName);
    if (file.is_open()) {
        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            string name, id, prereq;

            getline(ss, id, ',');
            getline(ss, name, ',');

            Course& course = courses[name]; // Retrieve or create the Course object
            course.name = name;
            course.id = id;

            while (getline(ss, prereq, ',')) {
                course.addPrerequisite(prereq);
            }
        }
        file.close();
        cout << "File opened successfully!\n";
    } else {
        cerr << "Error opening file: " << fileName << endl;
    }

    auto stop = high_resolution_clock::now(); // Stop timing
    auto duration = duration_cast<milliseconds>(stop - start);
    cout << "Time taken for loadDataStructure: " << duration.count() << " milliseconds\n";
}
// Prints the list of courses along with their IDs and prerequisites.
// Input: courses - The unordered_map containing course information.
void printCourseList(const unordered_map<string, Course>& courses) {
    auto start = high_resolution_clock::now(); // Start timing

    cout << "-------------------------\n";
    cout << "Course List:\n";
    for (const auto& pair : courses) {
        const auto& course = pair.second;
        cout << "Course Name: " << course.name << "\n";
        cout << "Course ID: " << course.id << "\n";

        if (!course.prerequisites.empty()) {
            cout << "Prerequisites:\n";
            for (const auto& prereq : course.prerequisites) {
                cout << "- " << prereq << "\n";
            }
        } else {
            cout << "No prerequisites.\n";
        }

        cout << "-------------------------\n";
    }

    auto stop = high_resolution_clock::now(); // Stop timing
    auto duration = duration_cast<milliseconds>(stop - start);
    cout << "Time taken for printCourseList: " << duration.count() << " milliseconds\n";
}
// Searches for a course by its ID and displays its details if found.
// Input: courses - The unordered_map containing course information.
//        targetID - The ID of the course to search for.
void searchCourseByID(const unordered_map<string, Course>& courses, const string& targetID) {
    auto start = high_resolution_clock::now(); // Start timing

    bool found = false;
    for (const auto& pair : courses) {
        const auto& course = pair.second;
        if (course.id == targetID) {
            cout << "Course found:\n";
            cout << "Course Name: " << course.name << "\n";
            cout << "Course ID: " << course.id << "\n";

            if (!course.prerequisites.empty()) {
                cout << "Prerequisites:\n";
                for (const auto& prereq : course.prerequisites) {
                    cout << "- " << prereq << "\n";
                }
            } else {
                cout << "No prerequisites.\n";
            }

            found = true;
            break;  // Exit the loop once the course is found
        }
    }

    if (!found) {
        cout << "Course with ID " << targetID << " not found.\n";
    }

    auto stop = high_resolution_clock::now(); // Stop timing
    auto duration = duration_cast<milliseconds>(stop - start);
    cout << "Time taken for searchCourseByID: " << duration.count() << " milliseconds\n";
}
// Displays the main menu and returns the user's choice.
// Output: choice - The user's menu choice.
int displayMenu() {
    int choice;
    cout << "-------------------------\n";
    cout << "Menu:\n";
    cout << "1. Load Data Structure\n";
    cout << "2. Print Course List\n";
    cout << "3. Search Course by ID\n";
    cout << "4. Exit\n";
    cout << "-------------------------\n";

    cout << "Enter your choice: ";
    cin >> choice;
    return choice;
}

int main() {
    unordered_map<string, Course> courses;

    int choice;
    do {
        choice = displayMenu();
        switch (choice) {
            case 1: {
                string fileName;
                cout << "Enter the file name (Absolute File Reference): ";
                cin >> fileName;
                loadDataStructure(fileName, courses);
                break;
            }
            case 2: {
                printCourseList(courses);
                break;
            }
            case 3: {
                string targetID;
                cout << "Enter the ID of the course to search: ";
                cin >> targetID;
                searchCourseByID(courses, targetID);
                break;
            }
            case 4: {
                cout << "Exiting program." << endl;
                break;
            }
            default:
                cout << "Invalid choice. Please enter a number between 1 and 4." << endl;
        }
    } while (choice != 4);

    return 0;
}
