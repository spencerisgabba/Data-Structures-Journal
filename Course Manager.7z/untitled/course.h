#ifndef COURSE_H    
#define COURSE_H

#include <string>
#include <set>

class Course {
public:
    std::string name;
    int id;
    std::set<std::string> prerequisites;
    Course(const std::string& name, int id) : name(name), id(id) {}
    void addPrerequisite(const std::string& prereq) {
        prerequisites.insert(prereq);
    }
};

#endif